---
title: 电脑软件推荐
createAt: 2024-03-17
updateAt: 2024-03-17
---

- 微信 — 社交软件。下载：[weixin.qq.com](http://weixin.qq.com)
- QQ — 社交软件。下载：[im.qq.com](http://im.qq.com)
- Geek — 高效、免费、小巧的软件卸载工具。官网：[geekuninstaller.com](http://geekuninstaller.com)
- 7-Zip — 开源压缩/解压工具，支持多种格式、压缩比高。官网：[7-zip.org](http://7-zip.org)
- Sparkle — 代理工具。主页：[sparkle](https://github.com/xishang0128/sparkle)
- PixPin — 简单强大的截图/贴图工具。官网：[pixpinapp.com](http://pixpinapp.com)
- Git — 分布式版本控制系统。官网：[git-scm.com](http://git-scm.com)
- VSCode — 免费开源的代码编辑器。官网：[code.visualstudio.com](http://code.visualstudio.com)
- Node.js — 基于 V8 的 JavaScript 运行时。官网：[nodejs.org](http://nodejs.org)
- DirectX 修复工具 — 检测并修复系统 DirectX 异常。介绍：[blog.csdn.net](http://blog.csdn.net)
- FNM - 超快的 Node 版本管理工具。官网：[Schniz/fnm:](https://github.com/Schniz/fnm) 🚀 [Fast and simple Node.js version manager, built in Rust](https://github.com/Schniz/fnm)
